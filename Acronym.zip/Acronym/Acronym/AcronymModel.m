//
//  AcronymModel.m
//  Acronym
//
//  Created by RameshChandra on 1/22/17.
//  Copyright © 2017 RameshChandra. All rights reserved.
//

#import "AcronymModel.h"

@implementation AcronymModel

-(id)initWithTitle:(NSDictionary *)listDict{
    self = [super init];
    if (self) {
        self.title = [listDict valueForKey:@"lf"];
        self.frequency = [NSString stringWithFormat:@"frequency:%@", [listDict valueForKey:@"freq"]];
        self.sinceFrom =[NSString stringWithFormat:@"since:%@", [listDict valueForKey:@"since"]];
        }
    return self;
}


@end

//
//  ViewController.m
//  Acronym
//
//  Created by RameshChandra on 1/22/17.
//  Copyright © 2017 RameshChandra. All rights reserved.
//

#import "ViewController.h"
#import "CustomCell.h"
#import "MBProgressHUD.h"
#import "AcronymModel.h"

@interface ViewController ()

@property (weak, nonatomic) IBOutlet UITableView *acronymTableView;
@property (weak, nonatomic) IBOutlet UILabel *noDataLabel;
@property (weak, nonatomic) IBOutlet UISearchBar *searchField;
@property (strong,nonatomic) NSMutableArray *acronymList;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    // Do any additional setup after loading the view, typically from a nib.
    self.title = @"Acronyms";
    _searchField.delegate = self;
    _acronymTableView.hidden = YES;
    _noDataLabel.hidden = YES;
    
    
}

#pragma Mark - TableView Delegates

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
 }

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return _acronymList.count;
 }

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    CustomCell *cell = [tableView dequeueReusableCellWithIdentifier:@"Cell"];
    AcronymModel *model = [[AcronymModel alloc]initWithTitle:[_acronymList objectAtIndex:indexPath.row]];
    cell.title.text= model.title;
    cell.frequency.text = model.frequency;
    cell.sinceLabel.text =model.sinceFrom;
    
    return cell;
    
}
#pragma Mark-Searchfield Delegates

- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar
{
    [searchBar resignFirstResponder];
}
- (void)searchBarTextDidEndEditing:(UISearchBar *)searchBar{
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    hud.label.text =@"Loading";
    
    hud.minSize = CGSizeMake(150.0f, 100.0f);
    
    dispatch_async(dispatch_get_global_queue(QOS_CLASS_USER_INITIATED, 0), ^{
        
        dispatch_async(dispatch_get_main_queue(), ^{
            AFHTTPSessionManager *manager = [[AFHTTPSessionManager alloc]initWithSessionConfiguration:[NSURLSessionConfiguration defaultSessionConfiguration]];
            manager.requestSerializer = [AFJSONRequestSerializer serializer];
            manager.responseSerializer = [AFHTTPResponseSerializer serializer];
            [manager.requestSerializer setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
            NSString *inputString=searchBar.text;
            NSString *path = [NSString stringWithFormat:@"http://www.nactem.ac.uk/software/acromine/dictionary.py?sf=%@",inputString];
            [manager GET:path parameters:nil progress:nil success:^(NSURLSessionTask *task, id responseObject) {
                NSError* error = nil;
                NSArray* json = [NSJSONSerialization
                                 JSONObjectWithData:responseObject
                                 
                                 options:kNilOptions
                                 error:&error];
                
                if(json.count!=0){
                    _noDataLabel.hidden = true;
                    _acronymTableView.hidden = false;
                    _acronymList=[[NSArray arrayWithObject:json][0][0] objectForKey:@"lfs"];
                    _acronymTableView.dataSource=self;
                    _acronymTableView.delegate=self;
                    [_acronymTableView reloadData];
                     [hud hideAnimated:YES  ];
                    
                }else{
                    _acronymTableView.hidden = true;
                    _noDataLabel.hidden = false;
                     [hud hideAnimated:YES  ];
                    
                }
                
                
            } failure:^(NSURLSessionTask *operation, NSError *error) {
                NSLog(@"Error: %@", error);
            }];
            
        });
    });
    
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end

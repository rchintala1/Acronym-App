//
//  AcronymModel.h
//  Acronym
//
//  Created by RameshChandra on 1/22/17.
//  Copyright © 2017 RameshChandra. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface AcronymModel : NSObject

@property (strong,nonatomic) NSString *title;
@property (strong,nonatomic) NSString *frequency;
@property (strong,nonatomic) NSString *sinceFrom;
-(id)initWithTitle:(NSDictionary *)listDict;

@end

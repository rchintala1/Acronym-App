//
//  ViewController.h
//  Acronym
//
//  Created by RameshChandra on 1/22/17.
//  Copyright © 2017 RameshChandra. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AFNetworking.h"

@interface ViewController : UIViewController<UITableViewDelegate,UITableViewDataSource,UISearchBarDelegate>


@end


//
//  AcronymTests.m
//  AcronymTests
//
//  Created by RameshChandra on 1/22/17.
//  Copyright © 2017 RameshChandra. All rights reserved.
//

#import <XCTest/XCTest.h>
#import "AcronymModel.h"

@interface AcronymTests : XCTestCase

@end

@implementation AcronymTests

- (void)setUp {
    [super setUp];
    // Put setup code here. This method is called before the invocation of each test method in the class.
    
}

-(void)testAcronymModel{
    NSDictionary *dictionary = @{
                                  @"freq": @"19",
                                     @"vars": @{
                                             @"freq": @18,
                                             @"lf": @"hjhj",
                                             @"since": @1979
                                             },
                                     @"lf": @"hjhj",
                                      @"since": @1979
                                    };
        
    AcronymModel *model =[[AcronymModel alloc]initWithTitle:dictionary];
    XCTAssertEqual(@"hjhj",model.title);
    
    
  }

- (void)tearDown {
    // Put teardown code here. This method is called after the invocation of each test method in the class.
    [super tearDown];
}

- (void)testExample {
    // This is an example of a functional test case.
    // Use XCTAssert and related functions to verify your tests produce the correct results.
}

- (void)testPerformanceExample {
    // This is an example of a performance test case.
    [self measureBlock:^{
        // Put the code you want to measure the time of here.
    }];
}

@end
